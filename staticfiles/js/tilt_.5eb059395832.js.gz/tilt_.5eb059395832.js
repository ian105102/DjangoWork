
VanillaTilt.init(document.querySelector(".stock_table"), {
    max: 3,
    speed: 200
});
VanillaTilt.init(document.querySelector(".chart"), {
    max: 3,
    speed: 200
});

$('.slider').slick({
    autoplay: true,
    infinite: true,
    autoplaySpeed: 1000,
   
});

